export const ENV = {
  API_URL: "http://192.168.1.51:3000",
};
